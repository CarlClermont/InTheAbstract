package resources;

/**
 * Marker - a dummy class so recourses can be found.
 * @author Carl Clermont
 * @version 09/24/28
 *
 */
public class Marker
{

}
